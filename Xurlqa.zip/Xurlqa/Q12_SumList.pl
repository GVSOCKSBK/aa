sumList :-
    write('Enter a list: '),
    read(List),
    sumList(List, N),
    format('The sum of the elements in the list is: ~w.~n', [N]).

sumList([],0):- !.
sumList([H|T],N):-
    sumList(T,N1),
    N is H+N1.
