cube(N, C) :-
    C is N * N * N.

process(stop) :- !.

process(N) :-
    cube(N, C),
    write('Cube of '), write(N), write(' is '),
    write(C), nl,
    write('Next item Please: '),  % Prompt for the next item
    read(X),
    process(X).  % Recursively call process/1 with the next item

start :-
    write('Enter a number or stop: '),
    read(Input),
    process(Input).

