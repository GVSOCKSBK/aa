conc :-
    write('Enter the first list: '),
    read(List1),
    write('Enter the second list: '),
    read(List2),
    conc(List1, List2, Result),
    format('The concatenated list is: ~w~n', [Result]).

conc([],L2,L2):- !.
conc([H|T],L2,[H|L3]) :-
    conc(T,L2,L3).
