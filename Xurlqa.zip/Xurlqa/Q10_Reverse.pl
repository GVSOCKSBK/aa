conc([],L2,L2):- !.
conc([H|T],L2,[H|L3]):-
    conc(T,L2,L3).

reverse :-
    write('Enter the list to reverse: '),
    read(List),
    reverse(List, Reversed),
    format('The reversed list is: ~w~n', [Reversed]).


reverse([],[]):- !.
reverse([E],[E]):- !.
reverse([H|T],R):-
    reverse(T,R1),
    conc(R1,[H],R).


