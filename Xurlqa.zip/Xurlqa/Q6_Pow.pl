pow :-
    write('Enter the base: '),
    read(X),
    write('Enter the exponent: '),
    read(N),
    pow(X, N, Z),
    format('~w raised to the power of ~w is ~w.~n', [X, N, Z]).

pow(_,0,1).
pow(X,N,Z):- P is N-1,pow(X,P,Q),Z is X*Q.
