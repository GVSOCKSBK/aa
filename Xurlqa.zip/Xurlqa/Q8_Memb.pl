memb :-
    write('Enter the element to search for: '),
    read(X),
    write('Enter the list: '),
    read(List),
    (   memb(X, List) ->
        format('~w is a member of the list.~n', [X])
    ;   format('~w is not a member of the list.~n', [X])
    ).

memb(X,[X|_]):- !.
memb(X,[_|T]):-
    memb(X,T).
memb(_, _) :- !, fail. % Fail for non-list inputs
