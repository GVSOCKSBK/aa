palindrom :-
    write('Enter a list: '),
    read(List),
    palindrome(List) ->
            format('The list is a palindrome.~n')
        ;   format('The list is not a palindrome.~n').



palindrome(L):-
    reverse(L,L).

reverse([],[]):- !.
reverse([E],[E]):- !.
reverse([H|T],R):-
    reverse(T,R1),
    append(R1,[H],R).

