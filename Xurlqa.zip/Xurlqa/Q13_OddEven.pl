evenLength :-
    write('Enter a list: '),
    read(List),
    evenLength(List) ->
            format('The list has an even length.~n')
        ;   format('The list does not have an even length.~n').

oddLength :-
    write('Enter a list: '),
    read(List),
    oddLength(List) ->
            format('The list has an odd length.~n')
        ;   format('The list does not have an odd length.~n').

evenLength([]):- !.
evenLength([_|T]):-
    oddLength(T).

oddLength([_]):-!.
oddLength([_|T]):-
    evenLength(T).
