sum :-
    write('Enter the first number: '),
    read(X),
    write('Enter the second number: '),
    read(Y),
    sum(X, Y, Z),
    format('The sum of ~w and ~w is ~w.~n', [X, Y, Z]).

sum(X,Y,Z):- Z is X + Y.
