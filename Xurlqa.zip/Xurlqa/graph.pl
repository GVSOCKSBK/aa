link(a,b).
link(a,c).
link(b,d).
link(c,d).
link(c,f).
link(d,e).
link(f,a).

path(X,X).
path(X,Z):-
    link(X,Y),
    path(Y,Z).
