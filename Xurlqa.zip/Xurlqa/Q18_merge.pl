
merge :-
    write('Enter the first list: '),
    read(List1),
    write('Enter the second list: '),
    read(List2),
    merge(List1, List2, Result),
    format('The merged list is: ~w.~n', [Result]).

merge([], L, L):-!.
merge(L, [], L):-!.
merge([X|Xs], [Y|Ys], [X|Zs]) :- X =< Y, !, merge(Xs, [Y|Ys], Zs).
merge([X|Xs], [Y|Ys], [Y|Zs]) :- X > Y, !, merge([X|Xs], Ys, Zs).

