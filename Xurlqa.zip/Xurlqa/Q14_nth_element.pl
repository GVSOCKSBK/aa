nth_number :-
    write('Enter the position: '),
    read(N),
    write('Enter a list: '),
    read(List),
        (   nth_number(N, List, X) ->
            format('The element at position ~w is: ~w.~n', [N, X])
        ;   format('Invalid position or list length.~n')
        ).

nth_number(1,[H|_],H):- !.
nth_number(N,[_|T],X):-
    N>1,
    N1 is N-1,
    nth_number(N1,T,X).
