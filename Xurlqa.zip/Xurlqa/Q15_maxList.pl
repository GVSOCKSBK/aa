maxList :-
    write('Enter a list: '),
    read(List),
    (    maxList(List, Max) ->
            format('The maximum element in the list is: ~w.~n', [Max])
        ;   format('The list is empty or contains invalid elements.~n')
    ).


maxList([], _) :- !, fail. % Fail if the list is empty
maxList([X], X) :- !.
maxList([H|T], Max) :-
    maxList(T, Tailmax),
    (   H > Tailmax -> Max = H
    ;   Max = Tailmax
    ).
