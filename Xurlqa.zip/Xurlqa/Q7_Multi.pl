multi :-
    write('Enter the first number: '),
    read(X),
    write('Enter the second number: '),
    read(Y),
    multi(X,Y,R),
    format('The product of ~w and ~w is ~w.~n', [X, Y, R]).


multi(_, 0, 0).

multi(X, Y, R) :-
    Y > 0,
    P is Y - 1,
    multi(X, P, R1),
    R is R1 + X.
