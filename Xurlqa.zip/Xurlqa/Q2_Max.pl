max :-
    write('Enter the first number: '),
    read(X),
    write('Enter the second number: '),
    read(Y),
    max(X, Y, Z),
    write('The maximum of '), write(X), write(' and '), write(Y), write(' is '), write(Z), write('.').

max(X,Y,Z):- X > Y, !, Z is X.
max(X,Y,Z):- X < Y, !,  Z is Y.
max(X,Y,_):- X =:= Y, !, fail.

