fib :-
    write('Enter the integer: '),
    read(N),
    fib(N,Z),
    format('The fibonacci number for ~w is ~w.~n', [N,Z]).

fib(1, 1) :- !.
fib(2, 1) :- !.
fib(N, Z) :-
    N > 2,
    P is N - 1,
    fib(P, A),
    Q is N - 2,
    fib(Q, B),
    Z is A + B.
