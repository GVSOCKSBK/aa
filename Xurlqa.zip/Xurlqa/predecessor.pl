parent(john, sarah).
parent(john, tom).
parent(sarah, emma).
parent(tom, alex).
parent(emma, mike).


predecessor(X, Y) :- parent(X, Y).
predecessor(X, Y) :- parent(X, Z), predecessor(Z, Y).

grandparent(X, Z) :- parent(X, Y), parent(Y, Z).
