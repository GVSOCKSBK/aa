insert_nth :-
    write('Enter the element to insert: '),
    read(Element),
    write('Enter the position to insert at: '),
    read(Position),
    write('Enter the list: '),
    read(List),
    (   insert_nth(Element, Position, List, Result) ->
            format('The list after insertion is: ~w.~n', [Result])
        ;   format('The position is out of bounds.~n')
    ).

insert_nth(Element, 1, List, [Element|List]) :- !.
insert_nth(Element, Position, [H|T], [H|R]) :-
    Position > 1,
    N1 is Position - 1,
    insert_nth(Element, N1, T, R).
insert_nth(_, _, _, _) :- !, fail. % Fail if the position is out of bounds
