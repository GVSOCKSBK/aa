fact :-
    write('Enter the number: '),
    read(N),
    fact(N,Z),
    format('The factorial of ~w is ~w.~n', [N,Z]).


fact(0,1):- !.
fact(N,Z):-
    N > 0,
    P is N-1,
    fact(P,Q),
    Z is N*Q.
