gcd :-
    write('Enter the first number: '),
    read(X),
    write('Enter the second number: '),
    read(Y),
    gcd(X, Y, G),
    format('The greatest common divisor of ~w and ~w is ~w.~n', [X, Y, G]).

gcd(X, 0, X) :-
    X > 0, !.
gcd(X, Y, G) :-
    Y > 0,
    Z is X mod Y,
    gcd(Y, Z, G).
gcd(_, _, _) :- !, fail. % Fail for negative integers or non-integer inputs
