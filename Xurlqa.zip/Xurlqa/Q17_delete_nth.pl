delete_nth :-
    write('Enter the position to delete: '),
    read(Position),
    write('Enter the list: '),
    read(List),
    delete_nth(Position, List, Result),
    format('The list after deletion is: ~w.~n', [Result]).


delete_nth(1, [_|T], T):- !.
delete_nth(N, [H|T], [H|R]) :-
    N > 1,
    N1 is N - 1,
    delete_nth(N1, T, R).


